@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Cursos</h1>
@endsection