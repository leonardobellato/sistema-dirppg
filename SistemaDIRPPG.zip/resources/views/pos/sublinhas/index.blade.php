@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Sublinhas</h1>
@endsection