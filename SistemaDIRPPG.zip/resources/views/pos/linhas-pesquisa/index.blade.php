@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Linhas de Pesquisa</h1>
@endsection