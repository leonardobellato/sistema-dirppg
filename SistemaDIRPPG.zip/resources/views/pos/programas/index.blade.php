@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Programas</h1>
@endsection