@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Disciplinas Externas</h1>
@endsection