@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Áreas de Concentração</h1>
@endsection