@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Análise de Inscrições</h1>
@endsection