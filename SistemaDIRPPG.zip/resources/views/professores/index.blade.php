@extends('layouts.app')

@section('title', 'Página Inicial')

@section('content')
    <h1>Professores</h1>
@endsection